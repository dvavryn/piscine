cat .gitignore
