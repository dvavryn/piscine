/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hkadsha <hkadsha@student.42vienna.com      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/09 13:31:11 by hkadsha           #+#    #+#             */
/*   Updated: 2025/02/09 13:31:12 by hkadsha          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	rush(int x, int y)
{
	int	h;
	int	v;

	h = 0;
	v = 0;
	while (v < y)
	{
		while (h < x)
		{
			if ((v == 0 && h == 0) || (v == y - 1 && h == 0))
				ft_putchar('A');
			else if ((v == 0 && h == x - 1) || (v == y - 1 && h == x - 1))
				ft_putchar('C');
			else if (h == 0 || h == x - 1)
				ft_putchar('B');
			else if (v == 0 || v == y - 1)
				ft_putchar('B');
			else
				ft_putchar(' ');
			h++;
		}
		h = 0;
		ft_putchar('\n');
		v++;
	}
}
