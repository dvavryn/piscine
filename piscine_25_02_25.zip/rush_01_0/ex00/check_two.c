/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_two.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bschwarz <bschwarz@42.fr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/06 13:26:59 by bschwarz          #+#    #+#             */
/*   Updated: 2025/02/07 13:29:33 by bschwarz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_check_two_d(char matrix[6][6], int i, int j)
{
	if (matrix[0][j] == '2' && matrix[3][j] == '3' && matrix[4][j] == '4')
	{
		matrix[1][j] = '1';
		matrix[2][j] = '2';
	}
	if (matrix[5][j] == '2' && matrix[2][j] == '3' && matrix[1][j] == '4')
	{
		matrix[4][j] = '1';
		matrix[3][j] = '2';
	}
	if (matrix[i][0] == '2' && matrix[i][3] == '3' && matrix[i][4] == '4')
	{
		matrix[i][1] = '1';
		matrix[i][2] = '2';
	}
	if (matrix[i][5] == '2' && matrix[i][2] == '3' && matrix[i][1] == '4')
	{
		matrix[i][4] = '1';
		matrix[i][3] = '2';
	}
}

void	ft_check_two_e(char matrix[6][6], int i, int j)
{
	if (matrix[0][j] == '2' && matrix[3][j] == '4' && matrix[4][j] == '3')
	{
		matrix[1][j] = '2';
		matrix[2][j] = '1';
	}
	if (matrix[5][j] == '2' && matrix[2][j] == '4' && matrix[1][j] == '3')
	{
		matrix[4][j] = '2';
		matrix[3][j] = '1';
	}
	if (matrix[i][0] == '2' && matrix[i][3] == '4' && matrix[i][4] == '3')
	{
		matrix[i][1] = '2';
		matrix[i][2] = '1';
	}
	if (matrix[i][5] == '2' && matrix[i][2] == '4' && matrix[i][1] == '3')
	{
		matrix[i][4] = '2';
		matrix[i][3] = '1';
	}
}

void	ft_check_two_c(char matrix[6][6])
{
	int	i;
	int	j;

	i = 0;
	while (i < 6)
	{
		j = 0;
		while (j < 6)
		{
			ft_check_two_d(matrix, i, j);
			ft_check_two_e(matrix, i, j);
			j++;
		}
		i++;
	}
}
