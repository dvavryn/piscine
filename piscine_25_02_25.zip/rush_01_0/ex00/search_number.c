/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   search_number.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bschwarz <bschwarz@42.fr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/06 13:26:59 by bschwarz          #+#    #+#             */
/*   Updated: 2025/02/07 13:29:33 by bschwarz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	search_number(char matrix[6][6], char c);

void	check_postion(char matrix[6][6], int i, int j, char c)
{
	int		k;
	int		d;

	d = 0;
	k = 1;
	while (k < 5)
	{
		if (matrix[k][j] == c || matrix[i][k] == c)
			d++;
		k++;
	}
	if (d < 1 && matrix[i][j] == ' ')
	{
		matrix[i][j] = c;
	}
	c--;
}

int	finish(char matrix[6][6])
{
	int	i;
	int	j;

	i = 1;
	while (i < 5)
	{
		j = 1;
		while (j < 5)
		{
			if (matrix[i][j] == ' ')
				return (1);
			j++;
		}
		i++;
	}
	return (0);
}

void	search_number(char matrix[6][6], char c)
{
	int	i;
	int	j;

	i = 1;
	while (i < 5)
	{
		j = 1;
		while (j < 5)
		{
			check_postion(matrix, i, j, c);
			j++;
		}
		i++;
	}
}
