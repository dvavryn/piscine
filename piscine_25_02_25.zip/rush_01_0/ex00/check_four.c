/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_four.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bschwarz <bschwarz@42.fr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/06 13:26:59 by bschwarz          #+#    #+#             */
/*   Updated: 2025/02/07 13:29:33 by bschwarz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_check_four_top(char matrix[6][6], int i, int j)
{
	matrix[i + 1][j] = '1';
	matrix[i + 2][j] = '2';
	matrix[i + 3][j] = '3';
	matrix[i + 4][j] = '4';
}

void	ft_check_four_bottom(char matrix[6][6], int i, int j)
{
	matrix[i - 1][j] = '1';
	matrix[i - 2][j] = '2';
	matrix[i - 3][j] = '3';
	matrix[i - 4][j] = '4';
}

void	ft_check_four_left(char matrix[6][6], int i, int j)
{
	matrix[i][j + 1] = '1';
	matrix[i][j + 2] = '2';
	matrix[i][j + 3] = '3';
	matrix[i][j + 4] = '4';
}

void	ft_check_four_right(char matrix[6][6], int i, int j)
{
	matrix[i][j - 1] = '1';
	matrix[i][j - 2] = '2';
	matrix[i][j - 3] = '3';
	matrix[i][j - 4] = '4';
}

void	ft_check_four(char matrix[6][6])
{
	int	i;
	int	j;

	i = 0;
	while (i < 6)
	{
		j = 0;
		while (j < 6)
		{
			if (matrix[i][j] == '4')
			{
				if (i == 0)
					ft_check_four_top(matrix, i, j);
				else if (i == 5)
					ft_check_four_bottom(matrix, i, j);
				else if (j == 0)
					ft_check_four_left(matrix, i, j);
				else if (j == 5)
					ft_check_four_right(matrix, i, j);
			}
			j++;
		}
		i++;
	}
}
